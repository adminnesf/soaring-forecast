"""New England paragliding forecast."""
